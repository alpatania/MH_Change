# Contextual Word Embeddings — Two-Script Pipeline

Produces interactive visualizations of contextual word embeddings from RoBERTa,
inspired by [Zimmerman et al., arXiv:2412.10924](https://arxiv.org/abs/2412.10924).

Two scripts, meant to be used in order:

| Script | Purpose |
|--------|---------|
| `final_layer_embeddings.py` | **Step 1 — the map.** Where does each passage-usage land in the final RoBERTa layer? Are there clusters? Which usages are outliers? |
| `contextual_embeddings.py`  | **Step 2 — the journey.** For a chosen subset of passages, how did each embedding travel through all layers to reach that position? |

Running Step 1 first lets you identify meaningful clusters and select representative
passages before investing in the more expensive trajectory analysis of Step 2.

---

## Installation (once)

```bash
pip install transformers torch scikit-learn plotly pandas numpy
pip install umap-learn   # optional, for --method umap in either script
```

---

## Data format

Both scripts accept the same CSV and auto-detect whether it has a header row.

### Named-column format (corpus query output, **with header**)

```
occurrence, search, text_id, document_file, genre, year, ..., word_id_1, match_word_1, ..., full_context
1, insan, 505250, mag_1855_505250.txt, MAG, 1855, ..., 5931, insane, ..., "dog . Crowds of idlers ..."
```

Default column mapping (matches the format above; change with `--wid-col`, `--word-col`, `--passage-col`):

| Role | Default column name |
|------|---------------------|
| Passage ID | `word_id_1` |
| Matched word | `match_word_1` |
| Passage text | `full_context` |

All other columns (e.g. `genre`, `year`, `match_pos_1`, `source`) are kept as metadata
and can be used for colouring and labelling points in `final_layer_embeddings.py`.

### Legacy three-column format (**no header**)

```
wid0879, insane, "passage text where the target word appears..."
wid0880, insane, "another passage containing insane..."
```

---

## Noise cleaning

Both scripts automatically remove `@` placeholder tokens before tokenisation.
These appear in corpus exports as variable-length sequences of space-separated
`@` signs (e.g. `@ @ @`, `@ @ @ @ @ @ @ @ @ @`) marking redacted text spans.
They are stripped and whitespace is normalised before the passage is passed to RoBERTa.

Pass `--no-clean` to disable this behaviour.

---

## Step 1 — `final_layer_embeddings.py`

Extracts one vector per passage (last RoBERTa layer, mean-pooled over the
word's tokens) and plots all passages in a single 2D or 3D scatter.

### What it produces

Each dot is one **passage**:

- **Position** — PCA or UMAP of the final hidden-state vector
- **Colour** — passage ID, a metadata column (e.g. `genre`, `year`), or k-means cluster
- **Hover** — passage ID, word form, metadata values, and a text snippet

### Minimal usage

```bash
python final_layer_embeddings.py --input data.csv --word insane
```

Saves `insane_final_layer.html` and `insane_final_layer_coords.csv`.

### Full options

```bash
python final_layer_embeddings.py \
  --input        data.csv          \  # CSV file
  --word         insane            \  # target word (case-insensitive)
  --wid-col      word_id_1         \  # column for passage ID (default: word_id_1)
  --word-col     match_word_1      \  # column for matched word (default: match_word_1)
  --passage-col  full_context      \  # column for passage text (default: full_context)
  --model        roberta-base      \  # roberta-base (default) or roberta-large
  --method       pca               \  # pca (default) or umap
  --dims         2                 \  # 2 (default) or 3
  --color-col    genre             \  # colour points by this column (e.g. genre, year)
  --label-col    year              \  # label points with this column
  --clusters     3                 \  # run k-means and colour by cluster
  --cosine-matrix                  \  # save pairwise cosine-similarity matrix as CSV
  --no-clean                       \  # disable @ token removal
  --device       cpu               \  # cpu (default) or cuda
  --output       insane_map.html      # output filename
```

### Recommended usage with real corpus data

```bash
# Colour by genre, discover natural groupings with k-means
python final_layer_embeddings.py --input insan_results.csv --word insane \
    --color-col genre --clusters 3 --cosine-matrix

# Colour by decade for diachronic analysis
python final_layer_embeddings.py --input insan_results.csv --word insane \
    --color-col year --method umap
```

The console prints which passage IDs landed in each cluster — copy those
into a subset CSV to feed into Step 2.

---

## Step 2 — `contextual_embeddings.py`

Extracts the hidden state at **every layer** for each passage, stacks them,
and plots each (passage × layer) pair. Lines connect the same passage across
layers, tracing its embedding trajectory through the model.

### What it produces

Each dot is one **(passage × layer)** pair:

- **Position** — PCA or UMAP of the hidden-state vector at that layer
- **Colour** — layer depth (dark = early, bright = late)
- **Connected lines** — trace the same passage across all layers
- **Hover** — passage ID, layer number, and a text snippet

### Minimal usage

```bash
python contextual_embeddings.py --input subset.csv --word insane
```

Saves `insane_embeddings.html` and `insane_embeddings_coords.csv`.

### Full options

```bash
python contextual_embeddings.py \
  --input        subset.csv        \  # CSV file (ideally a cluster subset from Step 1)
  --word         insane            \  # target word
  --wid-col      word_id_1         \  # column for passage ID (default: word_id_1)
  --word-col     match_word_1      \  # column for matched word (default: match_word_1)
  --passage-col  full_context      \  # column for passage text (default: full_context)
  --model        roberta-base      \  # roberta-base (default) or roberta-large
  --method       pca               \  # pca (default) or umap
  --dims         2                 \  # 2 (default) or 3
  --layers       all               \  # 'all', '0,4,8,12', or '0:13:2'
  --no-clean                       \  # disable @ token removal
  --device       cpu               \  # cpu (default) or cuda
  --output       insane_traj.html     # output filename
```

### Layer subsets (less crowded, faster)

```bash
# Every other layer
python contextual_embeddings.py --input subset.csv --word insane --layers 0:13:2

# Only the last four layers
python contextual_embeddings.py --input subset.csv --word insane --layers 9,10,11,12
```

---

## Recommended end-to-end workflow

```bash
# 1. Map all passages in the final layer; colour by genre; find 3 clusters
python final_layer_embeddings.py --input insan_results.csv --word insane \
    --color-col genre --clusters 3 --cosine-matrix

# 2. Inspect console output to see which word_id_1 values land in each cluster.
#    Filter the CSV to one representative per cluster and save as subset.csv.

# 3. Examine trajectories for those representatives
python contextual_embeddings.py --input subset.csv --word insane

# 4. Optionally use roberta-large for 24-layer richer trajectories
python contextual_embeddings.py --input subset.csv --word insane \
    --model roberta-large --device cuda
```

---

## How each script works internally

### `final_layer_embeddings.py`
1. Load CSV (auto-detect header); strip `@` sequences; filter to target word
2. Tokenise each passage with RoBERTa's BPE tokenizer
3. Locate the target word's token(s) via character-offset mapping
4. Forward pass → `last_hidden_state`; mean-pool over the word's tokens → one 768-dim vector per passage
5. Optional k-means on the full-dimensional matrix
6. PCA / UMAP → 2D or 3D coordinates
7. Plotly scatter, saved as self-contained HTML

### `contextual_embeddings.py`
Steps 1–3 identical, then for each layer:

4. Forward pass with `output_hidden_states=True`; mean-pool at every layer → one vector per (passage, layer)
5. Stack into matrix of shape `(n_passages × n_layers, hidden_dim)`
6. PCA / UMAP → 2D or 3D coordinates
7. Plotly scatter with dotted lines connecting layers within the same passage

---

## Tips

- **roberta-large** has 24 layers and 1024-dim hidden states (vs. 12 layers / 768-dim for base). Richer trajectories, but ~2× slower and needs ~1.4 GB RAM.
- Add `--device cuda` if you have a GPU.
- Word matching is case-insensitive, so `insane`, `Insane`, and `INSANE` are all found by `--word insane`.
- If a passage doesn't contain the target word after `@` removal, a warning is printed and that row is skipped.
- Both scripts save a `*_coords.csv` alongside the HTML for post-processing in R or other tools.
- The cosine-similarity matrix (`--cosine-matrix`) can be used with `hclust` in R or `scipy.cluster.hierarchy` in Python to build a dendrogram of passage similarity.
