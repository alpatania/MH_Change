"""
Contextual Word Embeddings Visualizer (trajectory across layers)
=================================================================
Extracts per-layer hidden states for a target word from RoBERTa and plots
each (passage × layer) pair so you can trace how each contextual usage
travels through the model — similar to Figure 9 of Zimmerman et al. (arXiv:2412.10924).

Use this as Step 2 after final_layer_embeddings.py has revealed the cluster
structure. Feed it a subset of representative passages, one per cluster.

DATA FORMAT
-----------
Accepts two formats, auto-detected by whether the file has a header row.

Named-column format (e.g. output from corpus query tools):
    occurrence, search, text_id, ..., word_id_1, ..., match_word_1, ..., full_context
    1, insan, 505250, ..., 5931, ..., insane, ..., "dog . Crowds of idlers ..."

Legacy three-column format (no header):
    wid0879, insane, "passage text..."

Column names are configurable; the defaults match the named-column format above.

NOISE CLEANING
--------------
@ placeholder tokens (e.g. "@ @ @ @ @ @ @ @ @ @") are stripped automatically
before tokenisation. Pass --no-clean to disable.

USAGE
-----
    python contextual_embeddings.py --input data.csv --word insane
    python contextual_embeddings.py --input data.csv --word insane --model roberta-large
    python contextual_embeddings.py --input data.csv --word insane --layers 0:13:2

REQUIREMENTS
------------
    pip install transformers torch scikit-learn plotly pandas numpy
    pip install umap-learn   # optional
"""

import argparse
import re
import sys

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.decomposition import PCA


# ── text cleaning ──────────────────────────────────────────────────────────────

def clean_passage(text: str) -> str:
    """Remove @ placeholder tokens and normalise whitespace."""
    text = re.sub(r'(?:@\s*)+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


# ── data loading ───────────────────────────────────────────────────────────────

def load_data(
    path: str,
    target_word: str | None,
    wid_col: str,
    word_col: str,
    passage_col: str,
    apply_cleaning: bool = True,
) -> pd.DataFrame:
    """
    Load CSV in either named-column (with header) or legacy three-column (no header) format.
    Auto-detects the format by checking whether the first row looks like a header.
    """
    # Peek at first row to detect header
    raw = pd.read_csv(path, nrows=1, header=None)
    first_row = [str(v).strip() for v in raw.iloc[0]]
    has_header = not first_row[0].replace('-', '').replace('_', '').isdigit()

    if has_header:
        df = pd.read_csv(path, header=0, dtype=str)
        df.columns = [c.strip() for c in df.columns]
        missing = [c for c in [wid_col, word_col, passage_col] if c not in df.columns]
        if missing:
            raise ValueError(
                f"Columns not found in CSV: {missing}\n"
                f"Available columns: {list(df.columns)}\n"
                f"Adjust --wid-col / --word-col / --passage-col."
            )
        out = df[[wid_col, word_col, passage_col]].copy()
        out.columns = ['wid', 'word', 'passage']
        # carry through any extra columns as metadata
        extra = [c for c in df.columns if c not in [wid_col, word_col, passage_col]]
        for c in extra:
            out[c] = df[c]
    else:
        df = pd.read_csv(path, header=None, dtype=str)
        out = df.iloc[:, :3].copy()
        out.columns = ['wid', 'word', 'passage']
        out['wid']     = out['wid'].str.strip()
        out['word']    = out['word'].str.strip()
        out['passage'] = out['passage'].str.strip().str.strip('"')

    if target_word:
        out = out[out['word'].str.lower() == target_word.lower()]

    if apply_cleaning:
        out['passage'] = out['passage'].apply(clean_passage)

    out = out.dropna(subset=['wid', 'word', 'passage']).reset_index(drop=True)
    print(f"Loaded {len(out)} rows  |  word forms: {out['word'].value_counts().to_dict()}")
    return out


# ── token location ─────────────────────────────────────────────────────────────

def find_target_token_span(tokenizer, passage: str, word: str) -> tuple[int, int] | None:
    m = re.search(r'\b' + re.escape(word) + r'\b', passage, re.IGNORECASE)
    if m is None:
        return None
    char_start, char_end = m.start(), m.end()
    enc = tokenizer(
        passage,
        return_offsets_mapping=True,
        truncation=True,
        max_length=512,
        add_special_tokens=True,
    )
    tok_start = tok_end = None
    for i, (cs, ce) in enumerate(enc['offset_mapping']):
        if cs == 0 and ce == 0:
            continue
        if cs <= char_start < ce:
            tok_start = i
        if cs < char_end <= ce:
            tok_end = i
            break
    if tok_start is None or tok_end is None:
        return None
    return tok_start, tok_end


# ── embedding extraction ───────────────────────────────────────────────────────

def extract_hidden_states(
    tokenizer, model, passage: str, word: str,
    device: str = 'cpu', layers: list[int] | None = None,
) -> dict[int, np.ndarray] | None:
    import torch
    span = find_target_token_span(tokenizer, passage, word)
    if span is None:
        print(f"  WARNING: '{word}' not found after cleaning — skipping.")
        return None
    tok_start, tok_end = span
    enc = tokenizer(
        passage, return_tensors='pt', truncation=True,
        max_length=512, add_special_tokens=True,
    ).to(device)
    with torch.no_grad():
        outputs = model(**enc)
    hidden = outputs.hidden_states
    if layers is None:
        layers = list(range(len(hidden)))
    result = {}
    for l in layers:
        vecs = hidden[l][0, tok_start:tok_end + 1, :]
        result[l] = vecs.mean(dim=0).cpu().numpy()
    return result


def build_embedding_matrix(
    df: pd.DataFrame, tokenizer, model,
    device: str = 'cpu', layers: list[int] | None = None,
) -> tuple[np.ndarray, list[dict]]:
    matrix_rows, metadata = [], []
    for _, row in df.iterrows():
        print(f"  {row['wid']} ({row['word']}) ...", end=' ', flush=True)
        hs = extract_hidden_states(tokenizer, model, row['passage'], row['word'],
                                   device=device, layers=layers)
        if hs is None:
            continue
        print('ok')
        for layer_idx, vec in hs.items():
            matrix_rows.append(vec)
            metadata.append({
                'wid': row['wid'],
                'word': row['word'],
                'layer': layer_idx,
                'passage_snippet': row['passage'][:120] + '…',
            })
    return np.array(matrix_rows), metadata


# ── dimensionality reduction ───────────────────────────────────────────────────

def reduce_dimensions(matrix: np.ndarray, method: str = 'pca',
                      n_components: int = 2, seed: int = 42) -> np.ndarray:
    if method == 'pca':
        return PCA(n_components=n_components, random_state=seed).fit_transform(matrix)
    elif method == 'umap':
        try:
            import umap
            return umap.UMAP(n_components=n_components, random_state=seed).fit_transform(matrix)
        except ImportError:
            print('umap-learn not installed — falling back to PCA.')
            return reduce_dimensions(matrix, 'pca', n_components, seed)
    raise ValueError(f"Unknown method '{method}'. Use 'pca' or 'umap'.")


# ── plotting ───────────────────────────────────────────────────────────────────

def make_figure(coords, metadata, method, model_name, word):
    df_meta = pd.DataFrame(metadata)
    df_meta['x'] = coords[:, 0]
    df_meta['y'] = coords[:, 1]
    if coords.shape[1] == 3:
        df_meta['z'] = coords[:, 2]

    unique_passages = df_meta['wid'].unique()
    palette = px.colors.qualitative.Dark24
    is_3d = coords.shape[1] == 3
    fig = go.Figure()

    for i, wid in enumerate(unique_passages):
        sub = df_meta[df_meta['wid'] == wid].sort_values('layer')
        color = palette[i % len(palette)]
        hover = [
            f"<b>{wid}</b> — Layer {r.layer}<br><i>{r.passage_snippet}</i>"
            for _, r in sub.iterrows()
        ]
        if is_3d:
            fig.add_trace(go.Scatter3d(
                x=sub['x'], y=sub['y'], z=sub['z'], mode='lines',
                line=dict(color=color, width=2), name=wid,
                showlegend=False, hoverinfo='skip',
            ))
            fig.add_trace(go.Scatter3d(
                x=sub['x'], y=sub['y'], z=sub['z'], mode='markers',
                marker=dict(size=5, color=sub['layer'], colorscale='Viridis',
                            showscale=(i == 0),
                            colorbar=dict(title='Layer') if i == 0 else None),
                name=wid, text=hover, hoverinfo='text',
            ))
        else:
            fig.add_trace(go.Scatter(
                x=sub['x'], y=sub['y'], mode='lines',
                line=dict(color=color, width=1, dash='dot'),
                name=wid, showlegend=False, hoverinfo='skip',
            ))
            fig.add_trace(go.Scatter(
                x=sub['x'], y=sub['y'], mode='markers+text',
                marker=dict(size=10, color=sub['layer'], colorscale='Viridis',
                            showscale=(i == 0),
                            colorbar=dict(title='Layer', x=1.02) if i == 0 else None,
                            line=dict(color=color, width=1.5)),
                text=[str(l) if l % 3 == 0 else '' for l in sub['layer']],
                textposition='top center', textfont=dict(size=9, color=color),
                name=wid, customdata=hover,
                hovertemplate='%{customdata}<extra></extra>',
            ))

    ax = method.upper()
    fig.update_layout(
        title=dict(
            text=f"Contextual embeddings of <i>'{word}'</i> across RoBERTa layers ({model_name})<br>"
                 f"<sup>{ax} of per-layer hidden states — each line = one passage, colour = layer depth</sup>",
            font=dict(size=15),
        ),
        xaxis_title=f'{ax} 1', yaxis_title=f'{ax} 2',
        legend_title='Passage (wid)', legend=dict(itemsizing='constant'),
        hovermode='closest', width=1100, height=700, template='plotly_white',
    )
    return fig


# ── layer spec parser ──────────────────────────────────────────────────────────

def parse_layer_spec(spec: str, max_layers: int) -> list[int]:
    if spec.lower() == 'all':
        return list(range(max_layers + 1))
    if ':' in spec:
        parts = [int(p) for p in spec.split(':')]
        return list(range(parts[0], parts[1], parts[2] if len(parts) > 2 else 1))
    return [int(x) for x in spec.split(',')]


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--input',       required=True)
    p.add_argument('--word',        default=None,     help='Target word (default: use all rows)')
    p.add_argument('--wid-col',     default='word_id_1', help='Column name for passage ID')
    p.add_argument('--word-col',    default='match_word_1', help='Column name for matched word')
    p.add_argument('--passage-col', default='full_context', help='Column name for passage text')
    p.add_argument('--model',       default='roberta-base',
                   choices=['roberta-base', 'roberta-large'])
    p.add_argument('--method',      default='pca', choices=['pca', 'umap'])
    p.add_argument('--dims',        default=2, type=int, choices=[2, 3])
    p.add_argument('--layers',      default='all')
    p.add_argument('--no-clean',    action='store_true',
                   help='Disable @ token removal')
    p.add_argument('--device',      default='cpu', choices=['cpu', 'cuda'])
    p.add_argument('--output',      default=None)
    args = p.parse_args()

    from transformers import RobertaModel, RobertaTokenizer

    df = load_data(
        args.input, args.word,
        wid_col=args.wid_col, word_col=args.word_col, passage_col=args.passage_col,
        apply_cleaning=not args.no_clean,
    )
    if df.empty:
        print('No data found. Check --word matches your CSV.')
        sys.exit(1)

    target_word = args.word or df['word'].iloc[0]
    output_path = args.output or f"{target_word}_embeddings.html"

    print(f'\nLoading {args.model} ...')
    tokenizer = RobertaTokenizer.from_pretrained(args.model)
    model = RobertaModel.from_pretrained(args.model, output_hidden_states=True)
    model.eval().to(args.device)
    n_layers = model.config.num_hidden_layers
    layer_indices = parse_layer_spec(args.layers, n_layers)
    print(f'  {n_layers} transformer layers  |  extracting: {layer_indices}')

    print(f"\nExtracting embeddings ...")
    matrix, metadata = build_embedding_matrix(
        df, tokenizer, model, device=args.device, layers=layer_indices
    )
    if len(matrix) == 0:
        print('No embeddings extracted.')
        sys.exit(1)

    print(f'\nMatrix: {matrix.shape}')
    print(f'Applying {args.method.upper()} → {args.dims}D ...')
    coords = reduce_dimensions(matrix, method=args.method, n_components=args.dims)

    print('Building figure ...')
    fig = make_figure(coords, metadata, args.method, args.model, target_word)
    fig.write_html(output_path, include_plotlyjs='cdn')
    print(f'\n✓  Plot: {output_path}')

    df_out = pd.DataFrame(metadata)
    df_out[['pc1', 'pc2'] if args.dims == 2 else ['pc1', 'pc2', 'pc3']] = coords
    csv_path = output_path.replace('.html', '_coords.csv')
    df_out.to_csv(csv_path, index=False)
    print(f'   Coords: {csv_path}')


if __name__ == '__main__':
    main()
