"""
Final-Layer Contextual Embeddings
===================================
Extracts the last hidden-state vector for a target word from RoBERTa,
applies PCA or UMAP, and produces an interactive Plotly scatter plot.

Run this first (Step 1) to see where each contextual usage lands — how many
clusters exist, which passages are outliers, which usages are semantically
close — then use contextual_embeddings.py (Step 2) on a chosen subset to
trace the layer trajectories of representative passages.

DATA FORMAT
-----------
Accepts two formats, auto-detected by whether the file has a header row.

Named-column format (e.g. output from corpus query tools):
    occurrence, search, text_id, ..., word_id_1, ..., match_word_1, ..., full_context, genre, year
    1, insan, 505250, ..., 5931, ..., insane, ..., "dog . Crowds...", MAG, 1855

Legacy three-column format (no header):
    wid0879, insane, "passage text..."

Column names are configurable; the defaults match the named-column format above.

NOISE CLEANING
--------------
@ placeholder tokens (e.g. "@ @ @ @ @ @ @ @ @ @") are stripped automatically.
Pass --no-clean to disable.

USAGE
-----
    python final_layer_embeddings.py --input data.csv --word insane
    python final_layer_embeddings.py --input data.csv --word insane --color-col genre
    python final_layer_embeddings.py --input data.csv --word insane --clusters 3 --cosine-matrix

REQUIREMENTS
------------
    pip install transformers torch scikit-learn plotly pandas numpy
    pip install umap-learn   # optional
"""

import argparse
import re
import sys

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.decomposition import PCA
from sklearn.preprocessing import normalize


# ── text cleaning ──────────────────────────────────────────────────────────────

def clean_passage(text: str) -> str:
    """Remove @ placeholder tokens and normalise whitespace."""
    text = re.sub(r'(?:@\s*)+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


# ── data loading ───────────────────────────────────────────────────────────────

def load_data(
    path: str,
    target_word: str | None,
    wid_col: str,
    word_col: str,
    passage_col: str,
    apply_cleaning: bool = True,
) -> pd.DataFrame:
    """
    Load CSV in either named-column or legacy three-column format.
    Auto-detects header and carries all extra columns through as metadata.
    """
    raw = pd.read_csv(path, nrows=1, header=None)
    first_row = [str(v).strip() for v in raw.iloc[0]]
    has_header = not first_row[0].replace('-', '').replace('_', '').isdigit()

    if has_header:
        df = pd.read_csv(path, header=0, dtype=str)
        df.columns = [c.strip() for c in df.columns]
        missing = [c for c in [wid_col, word_col, passage_col] if c not in df.columns]
        if missing:
            raise ValueError(
                f"Columns not found: {missing}\n"
                f"Available: {list(df.columns)}\n"
                f"Adjust --wid-col / --word-col / --passage-col."
            )
        # rename the three core columns to standard names
        df = df.rename(columns={wid_col: 'wid', word_col: 'word', passage_col: 'passage'})
    else:
        df = pd.read_csv(path, header=None, dtype=str)
        df = df.rename(columns={0: 'wid', 1: 'word', 2: 'passage'})
        df['wid']     = df['wid'].str.strip()
        df['word']    = df['word'].str.strip()
        df['passage'] = df['passage'].str.strip().str.strip('"')

    if target_word:
        df = df[df['word'].str.lower() == target_word.lower()]

    if apply_cleaning:
        df['passage'] = df['passage'].apply(clean_passage)

    df = df.dropna(subset=['wid', 'word', 'passage']).reset_index(drop=True)
    print(f"Loaded {len(df)} rows  |  word forms: {df['word'].value_counts().to_dict()}")
    if 'genre' in df.columns:
        print(f"  Genres: {df['genre'].value_counts().to_dict()}")
    if 'year' in df.columns:
        print(f"  Year range: {df['year'].min()} – {df['year'].max()}")
    return df


# ── token location ─────────────────────────────────────────────────────────────

def find_target_token_span(tokenizer, passage: str, word: str) -> tuple[int, int] | None:
    m = re.search(r'\b' + re.escape(word) + r'\b', passage, re.IGNORECASE)
    if m is None:
        return None
    char_start, char_end = m.start(), m.end()
    enc = tokenizer(
        passage,
        return_offsets_mapping=True,
        truncation=True,
        max_length=512,
        add_special_tokens=True,
    )
    tok_start = tok_end = None
    for i, (cs, ce) in enumerate(enc['offset_mapping']):
        if cs == 0 and ce == 0:
            continue
        if cs <= char_start < ce:
            tok_start = i
        if cs < char_end <= ce:
            tok_end = i
            break
    if tok_start is None or tok_end is None:
        return None
    return tok_start, tok_end


# ── embedding extraction ───────────────────────────────────────────────────────

def extract_final_layer(
    tokenizer, model, passage: str, word: str, device: str = 'cpu'
) -> np.ndarray | None:
    import torch
    span = find_target_token_span(tokenizer, passage, word)
    if span is None:
        return None
    tok_start, tok_end = span
    enc = tokenizer(
        passage, return_tensors='pt', truncation=True,
        max_length=512, add_special_tokens=True,
    ).to(device)
    with torch.no_grad():
        outputs = model(**enc)
    vecs = outputs.last_hidden_state[0, tok_start:tok_end + 1, :]
    return vecs.mean(dim=0).cpu().numpy()


def build_embedding_matrix(
    df: pd.DataFrame, tokenizer, model, device: str = 'cpu'
) -> tuple[np.ndarray, pd.DataFrame]:
    vecs, keep_idx = [], []
    for idx, row in df.iterrows():
        print(f"  {row['wid']} ({row['word']}) ...", end=' ', flush=True)
        vec = extract_final_layer(tokenizer, model, row['passage'], row['word'], device)
        if vec is None:
            print("SKIPPED (word not found after cleaning)")
        else:
            print('ok')
            vecs.append(vec)
            keep_idx.append(idx)
    return np.array(vecs), df.loc[keep_idx].reset_index(drop=True)


# ── dimensionality reduction ───────────────────────────────────────────────────

def reduce_dimensions(matrix: np.ndarray, method: str = 'pca',
                      n_components: int = 2, seed: int = 42) -> np.ndarray:
    if method == 'pca':
        return PCA(n_components=n_components, random_state=seed).fit_transform(matrix)
    elif method == 'umap':
        try:
            import umap
            return umap.UMAP(n_components=n_components, random_state=seed).fit_transform(matrix)
        except ImportError:
            print('umap-learn not installed — falling back to PCA.')
            return reduce_dimensions(matrix, 'pca', n_components, seed)
    raise ValueError(f"Unknown method '{method}'.")


# ── cosine similarity ──────────────────────────────────────────────────────────

def save_cosine_matrix(matrix: np.ndarray, meta: pd.DataFrame, out_path: str) -> None:
    normed = normalize(matrix, norm='l2')
    sim = normed @ normed.T
    pd.DataFrame(sim, index=meta['wid'], columns=meta['wid']).to_csv(out_path)
    print(f'  Cosine-similarity matrix: {out_path}')


# ── clustering ────────────────────────────────────────────────────────────────

def cluster_embeddings(matrix: np.ndarray, k: int, seed: int = 42) -> np.ndarray:
    from sklearn.cluster import KMeans
    return KMeans(n_clusters=k, random_state=seed, n_init='auto').fit_predict(matrix)


# ── plotting ───────────────────────────────────────────────────────────────────

def make_figure(
    coords: np.ndarray, meta: pd.DataFrame,
    method: str, model_name: str, word: str,
    color_col: str | None = None,
    label_col: str | None = None,
    clusters: np.ndarray | None = None,
) -> go.Figure:
    df_plot = meta.copy()
    df_plot['x'] = coords[:, 0]
    df_plot['y'] = coords[:, 1]
    if coords.shape[1] == 3:
        df_plot['z'] = coords[:, 2]

    if clusters is not None:
        df_plot['_color'] = [f'Cluster {c}' for c in clusters]
        legend_title = 'Cluster'
    elif color_col and color_col in df_plot.columns:
        df_plot['_color'] = df_plot[color_col].astype(str)
        legend_title = color_col
    else:
        df_plot['_color'] = df_plot['wid'].astype(str)
        legend_title = 'Passage (wid)'

    if label_col and label_col in df_plot.columns:
        df_plot['_label'] = df_plot[label_col].astype(str)
    else:
        df_plot['_label'] = df_plot['wid'].astype(str)

    color_values = sorted(df_plot['_color'].unique())
    palette = px.colors.qualitative.Dark24 if len(color_values) <= 24 else px.colors.qualitative.Alphabet
    color_map = {v: palette[i % len(palette)] for i, v in enumerate(color_values)}

    is_3d = coords.shape[1] == 3
    fig = go.Figure()

    for group_val in color_values:
        sub = df_plot[df_plot['_color'] == group_val]
        color = color_map[group_val]

        # build hover: always show wid + snippet; optionally show metadata
        def hover_text(row):
            parts = [f"<b>{row['wid']}</b>  ({row['word']})"]
            for mc in [color_col, label_col]:
                if mc and mc in row.index and mc not in ('wid', 'word', 'passage'):
                    parts.append(f"{mc}: {row[mc]}")
            parts.append(row['passage'][:160] + '…')
            return '<br>'.join(parts)

        hover = [hover_text(r) for _, r in sub.iterrows()]

        common = dict(
            name=str(group_val),
            customdata=hover,
            hovertemplate='%{customdata}<extra></extra>',
            text=sub['_label'].tolist(),
        )
        marker_kwargs = dict(color=color, opacity=0.85,
                             line=dict(color='white', width=1))
        if is_3d:
            fig.add_trace(go.Scatter3d(
                x=sub['x'], y=sub['y'], z=sub['z'],
                mode='markers+text',
                marker=dict(size=8, **marker_kwargs),
                textposition='top center', textfont=dict(size=9),
                **common,
            ))
        else:
            fig.add_trace(go.Scatter(
                x=sub['x'], y=sub['y'],
                mode='markers+text',
                marker=dict(size=12, **marker_kwargs),
                textposition='top center', textfont=dict(size=10),
                **common,
            ))

    ax = method.upper()
    color_desc = ('cluster' if clusters is not None
                  else (color_col if color_col else 'passage'))
    fig.update_layout(
        title=dict(
            text=f"Final-layer contextual embeddings of <i>'{word}'</i> ({model_name})<br>"
                 f"<sup>{ax} of last hidden state — colour = {color_desc} — hover for passage text</sup>",
            font=dict(size=15),
        ),
        xaxis_title=f'{ax} 1', yaxis_title=f'{ax} 2',
        legend_title=legend_title,
        legend=dict(itemsizing='constant'),
        hovermode='closest', width=1100, height=700, template='plotly_white',
    )
    return fig


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--input',        required=True)
    p.add_argument('--word',         default=None)
    p.add_argument('--wid-col',      default='word_id_1')
    p.add_argument('--word-col',     default='match_word_1')
    p.add_argument('--passage-col',  default='full_context')
    p.add_argument('--model',        default='roberta-base',
                   choices=['roberta-base', 'roberta-large'])
    p.add_argument('--method',       default='pca', choices=['pca', 'umap'])
    p.add_argument('--dims',         default=2, type=int, choices=[2, 3])
    p.add_argument('--color-col',    default=None,
                   help='Column to colour points by (e.g. genre, year)')
    p.add_argument('--label-col',    default=None,
                   help='Column to label points with')
    p.add_argument('--clusters',     default=None, type=int,
                   help='Number of k-means clusters')
    p.add_argument('--cosine-matrix', action='store_true')
    p.add_argument('--no-clean',     action='store_true',
                   help='Disable @ token removal')
    p.add_argument('--device',       default='cpu', choices=['cpu', 'cuda'])
    p.add_argument('--output',       default=None)
    args = p.parse_args()

    from transformers import RobertaModel, RobertaTokenizer

    df = load_data(
        args.input, args.word,
        wid_col=args.wid_col, word_col=args.word_col, passage_col=args.passage_col,
        apply_cleaning=not args.no_clean,
    )
    if df.empty:
        print('No data found.')
        sys.exit(1)

    target_word = args.word or df['word'].iloc[0]
    output_path = args.output or f"{target_word}_final_layer.html"

    print(f'\nLoading {args.model} ...')
    tokenizer = RobertaTokenizer.from_pretrained(args.model)
    model = RobertaModel.from_pretrained(args.model)
    model.eval().to(args.device)
    print(f'  Hidden size: {model.config.hidden_size}')

    print(f"\nExtracting final-layer embeddings ...")
    matrix, meta = build_embedding_matrix(df, tokenizer, model, device=args.device)
    if len(matrix) == 0:
        print('No embeddings extracted.')
        sys.exit(1)
    print(f'\nMatrix: {matrix.shape}')

    if args.cosine_matrix:
        save_cosine_matrix(matrix, meta, output_path.replace('.html', '_cosine.csv'))

    cluster_labels = None
    if args.clusters:
        print(f'\nRunning k-means (k={args.clusters}) ...')
        cluster_labels = cluster_embeddings(matrix, args.clusters)
        meta['cluster'] = cluster_labels
        for k in range(args.clusters):
            members = meta[meta['cluster'] == k]['wid'].tolist()
            print(f'  Cluster {k}: {members}')

    print(f'Applying {args.method.upper()} → {args.dims}D ...')
    coords = reduce_dimensions(matrix, method=args.method, n_components=args.dims)

    print('Building figure ...')
    fig = make_figure(
        coords, meta, args.method, args.model, target_word,
        color_col=args.color_col, label_col=args.label_col,
        clusters=cluster_labels,
    )
    fig.write_html(output_path, include_plotlyjs='cdn')
    print(f'\n✓  Plot: {output_path}')

    df_out = meta.copy()
    coord_cols = ['pc1', 'pc2'] if args.dims == 2 else ['pc1', 'pc2', 'pc3']
    df_out[coord_cols] = coords
    csv_path = output_path.replace('.html', '_coords.csv')
    df_out.to_csv(csv_path, index=False)
    print(f'   Coords: {csv_path}')


if __name__ == '__main__':
    main()
